package com.haxvq.haxtab.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Changes only the local TAB rendering result. No packets or server data are modified.
 */
@Mixin(PlayerTabOverlay.class)
public abstract class PlayerTabOverlayMixin {

    /**
     * Move the authenticated local player entry to index zero by UUID. The remaining
     * entries retain the exact order selected by vanilla/server team sorting.
     */
    @Inject(method = "getPlayerInfos", at = @At("RETURN"), cancellable = true)
    private void haxtab$putLocalPlayerFirst(CallbackInfoReturnable<List<PlayerInfo>> cir) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || cir.getReturnValue() == null || cir.getReturnValue().isEmpty()) {
            return;
        }

        UUID entityUuid = minecraft.player.getUUID();
        List<PlayerInfo> ordered = new ArrayList<>(cir.getReturnValue());
        int localIndex = -1;

        for (int i = 0; i < ordered.size(); i++) {
            UUID entryUuid = ordered.get(i).getProfile().id();
            if (minecraft.isLocalPlayer(entryUuid)) {
                localIndex = i;
                break;
            }
            // Some offline/proxy setups expose the local entity UUID instead of the
            // authenticated account UUID. Use it only as a fallback match.
            if (localIndex < 0 && entityUuid.equals(entryUuid)) {
                localIndex = i;
            }
        }

        if (localIndex > 0) {
            PlayerInfo localEntry = ordered.remove(localIndex);
            ordered.add(0, localEntry);
            cir.setReturnValue(ordered);
        }
    }

    /**
     * Vanilla's PlayerInfo contains no remote operator-permission field. Mark the
     * status as unknown rather than guessing. Appending the original Component keeps
     * server-provided nickname text and formatting intact.
     */
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void haxtab$showUnknownOperatorStatus(PlayerInfo info,
                                                   CallbackInfoReturnable<Component> cir) {
        Component original = cir.getReturnValue();
        if (original == null) {
            return;
        }

        cir.setReturnValue(Component.literal("[?] ").withStyle(ChatFormatting.GRAY).append(original));
    }
}
