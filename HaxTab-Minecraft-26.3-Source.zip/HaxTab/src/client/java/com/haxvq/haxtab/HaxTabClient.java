package com.haxvq.haxtab;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HaxTabClient implements ClientModInitializer {
    public static final String MOD_ID = "haxtab";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("HaxTab initialized: local UUID-first TAB sorting enabled.");
        LOGGER.info("Remote operator status is not exposed by vanilla multiplayer; [?] means unverified.");
    }
}
