# HaxTab

A client-side Fabric mod for **Minecraft Java 26.3**.

## Features

- Moves the local player to the first TAB position by the authenticated local account UUID (with the local entity UUID as a fallback for offline/proxy setups).
- Does not hardcode a username and does not change server data, permissions, packets, or rank.
- Leaves every other entry in the order vanilla/server sorting selected.
- Preserves server-provided display names, nicknames, player heads, ping indicators, and formatting by sorting `PlayerInfo` objects without replacing their display-name components.
- Adds `[?]` before each displayed name to mean **operator status unverified**. Vanilla multiplayer does not send ordinary clients the remote server's operator list or a per-player OP flag. HaxTab intentionally never guesses and never labels someone `[OP]` without verifiable data.

## Compatibility

The project targets Minecraft 26.3 and uses the 26.3 non-obfuscated Fabric toolchain:

- Minecraft: `26.3`
- Fabric Loader: `0.20.1`
- Fabric API: `0.166.2+26.3`
- Fabric Loom: `1.19-SNAPSHOT`
- Gradle: `9.6.0`
- Java: `25`

Minecraft 26.1+ uses unobfuscated game names. This project therefore uses the `net.fabricmc.fabric-loom` plugin and does not declare Yarn mappings. The mixin targets the 26.3 `PlayerTabOverlay#getPlayerInfos()` and `getNameForDisplay(PlayerInfo)` methods.

## Build with GitHub Actions

1. Upload the contents of this folder to a GitHub repository.
2. Open **Actions**.
3. Select **Build HaxTab**.
4. Choose **Run workflow**.
5. Download the `HaxTab-Minecraft-26.3` artifact after the run succeeds.
6. Put the generated `haxtab-1.0.0.jar` in the Fabric instance's `mods` folder. Install a matching Fabric API build as well.

The workflow installs Java 25 and Gradle 9.6.0, runs `gradle clean build`, and uploads the JAR from `build/libs`.

## Local build

With JDK 25 and Gradle 9.6.0 installed, run:

```bash
gradle clean build
```

The installable JAR is written to `build/libs/haxtab-1.0.0.jar`.

## Important limitations

- This is a client-only visual change. Other players do not see your modified TAB order.
- A remote server can still omit your player from its player list; a client mod cannot display an entry the server does not send.
- Nickname recognition is based on the authenticated UUID, not the visible nickname. The visible name remains whatever vanilla receives from the server. On offline/proxy servers that rewrite both UUID and nickname, there may be no reliable client-side way to associate the entry with the authenticated account.
- Remote OP status is unavailable through the vanilla multiplayer player-list protocol. `[?]` is deliberately an unknown marker, not an OP claim.

## Build status of this delivered archive

The source project and CI workflow are included. A compiled JAR is **not** included because this execution environment has Java 21, while the Minecraft 26.3 toolchain requires Java 25. The GitHub Actions workflow is configured to compile it using Java 25. No file in this archive is being presented as a compiled mod JAR.
