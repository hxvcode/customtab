package com.customtab.mixin;

import com.customtab.client.ClientOpState;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerTabOverlay.class)
public abstract class PlayerTabOverlayMixin {

    /** Feature A: move the local player to the very top. Matched by UUID, so servers that
     *  rename you still work (the server's custom TAB name is kept as-is). */
    @Inject(method = "getPlayerInfos", at = @At("RETURN"), cancellable = true)
    private void customtab$selfFirst(CallbackInfoReturnable<List<PlayerInfo>> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        UUID self = mc.player.getUUID();
        List<PlayerInfo> sorted = new ArrayList<>(cir.getReturnValue());
        for (int i = 0; i < sorted.size(); i++) {
            if (self.equals(sorted.get(i).getProfile().id())) {
                if (i > 0) sorted.add(0, sorted.remove(i));
                break;
            }
        }
        cir.setReturnValue(sorted);
    }

    /** Feature B: prefix real operators (as reported by the server-side companion) with [OP]. */
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void customtab$opTag(PlayerInfo info, CallbackInfoReturnable<Component> cir) {
        if (ClientOpState.isOp(info.getProfile().id())) {
            cir.setReturnValue(Component.literal("[OP] ")
                    .withStyle(ChatFormatting.RED, ChatFormatting.BOLD)
                    .append(cir.getReturnValue()));
        }
    }
}
