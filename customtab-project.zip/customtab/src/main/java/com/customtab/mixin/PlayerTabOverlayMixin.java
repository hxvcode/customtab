package com.customtab.mixin;

import com.customtab.client.ClientOpState;
import com.customtab.client.TabConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerTabOverlay.class)
public abstract class PlayerTabOverlayMixin {

    private static boolean customtab$logged = false;

    /** Feature A: put YOU first. Tries (1) real UUID, (2) real username, (3) nicknames from config/customtab.txt
     *  matched against the name the server displays. Works even if the server uses fake TAB entries. */
    @Inject(method = "getPlayerInfos", at = @At("RETURN"), cancellable = true)
    private void customtab$selfFirst(CallbackInfoReturnable<List<PlayerInfo>> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        UUID self = mc.player.getUUID();
        String realName = mc.getUser().getName();
        PlayerTabOverlay overlay = (PlayerTabOverlay) (Object) this;

        List<PlayerInfo> list = new ArrayList<>(cir.getReturnValue());
        int byUuid = -1, byName = -1, byNick = -1;
        for (int i = 0; i < list.size(); i++) {
            PlayerInfo info = list.get(i);
            if (byUuid < 0 && self.equals(info.getProfile().id())) byUuid = i;
            if (byName < 0 && realName.equalsIgnoreCase(info.getProfile().name())) byName = i;
            if (byNick < 0 && !TabConfig.nicknames().isEmpty()) {
                String shown = overlay.getNameForDisplay(info).getString().toLowerCase();
                for (String n : TabConfig.nicknames()) {
                    if (shown.contains(n)) { byNick = i; break; }
                }
            }
        }
        int idx = byUuid >= 0 ? byUuid : byName >= 0 ? byName : byNick;
        if (!customtab$logged) {
            customtab$logged = true;
            System.out.println("[customtab] self index: uuid=" + byUuid + " name=" + byName + " nick=" + byNick
                    + " (realName=" + realName + ", entries=" + list.size() + ")");
        }
        if (idx > 0) list.add(0, list.remove(idx));
        cir.setReturnValue(list);
    }

    /** Feature B: prefix real operators (as reported by the server-side companion) with [OP]. */
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void customtab$opTag(PlayerInfo info, CallbackInfoReturnable<Component> cir) {
        if (ClientOpState.isOp(info.getProfile().id())) {
            cir.setReturnValue(Component.literal("[OP] ")
                    .withStyle(ChatFormatting.RED, ChatFormatting.BOLD)
                    .append(cir.getReturnValue()));
        }
    }
}
