package com.customtab.client;

import com.customtab.OpListPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class CustomTabClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(OpListPayload.TYPE,
                (payload, context) -> ClientOpState.set(payload.ops()));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientOpState.clear());
    }
}
