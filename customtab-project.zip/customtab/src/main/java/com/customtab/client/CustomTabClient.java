package com.customtab.client;

import com.customtab.OpListPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class CustomTabClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        System.out.println("[customtab] v1.1.0 loaded");
        TabConfig.load();
        ClientPlayNetworking.registerGlobalReceiver(OpListPayload.TYPE,
                (payload, context) -> ClientOpState.set(payload.ops()));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> TabConfig.load());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientOpState.clear());
    }
}
