package com.customtab.client;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;

/** Reads config/customtab.txt: one nickname per line (what the server shows for YOU in TAB). */
public final class TabConfig {
    private static volatile List<String> nicknames = new ArrayList<>();

    public static List<String> nicknames() { return nicknames; }

    public static void load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("customtab.txt");
        try {
            if (!Files.exists(p)) {
                Files.writeString(p, "# Custom Tab List\n"
                        + "# Type the name(s) the server shows for YOU in the TAB list, one per line.\n"
                        + "# Case does not matter, colors/ranks are ignored. Example:\n"
                        + "# _Frazzlee\n");
            }
            List<String> out = new ArrayList<>();
            for (String line : Files.readAllLines(p)) {
                String t = line.trim();
                if (!t.isEmpty() && !t.startsWith("#")) out.add(t.toLowerCase());
            }
            nicknames = out;
        } catch (Exception e) {
            System.err.println("[customtab] could not read config: " + e);
        }
    }

    private TabConfig() {}
}
