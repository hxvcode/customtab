package com.haxtab;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.NameAndId;

/**
 * Common/server side. When installed on a server (or an integrated server) it reads the REAL op list
 * and tells every client that has this mod. Nothing is guessed or hardcoded.
 */
public class CustomTabMod implements ModInitializer {
    private int tick = 0;

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.clientboundPlay().register(OpListPayload.TYPE, OpListPayload.CODEC);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> broadcast(server));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> broadcast(server));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++tick >= 100) { // every 5s, catches /op and /deop
                tick = 0;
                broadcast(server);
            }
        });
    }

    private static void broadcast(MinecraftServer server) {
        List<UUID> ops = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            NameAndId id = new NameAndId(p.getUUID(), p.getGameProfile().name());
            if (server.getPlayerList().isOp(id)) ops.add(p.getUUID());
        }
        OpListPayload payload = new OpListPayload(ops);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (ServerPlayNetworking.canSend(p, OpListPayload.TYPE)) {
                ServerPlayNetworking.send(p, payload);
            }
        }
    }
}
