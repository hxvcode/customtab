package com.haxtab;

import io.netty.buffer.ByteBuf;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server -> client: UUIDs of every online player that is a real operator. */
public record OpListPayload(List<UUID> ops) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<OpListPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath("haxtab", "op_list"));

    public static final StreamCodec<ByteBuf, OpListPayload> CODEC = StreamCodec.composite(
            UUIDUtil.STREAM_CODEC.apply(ByteBufCodecs.list()), OpListPayload::ops, OpListPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
