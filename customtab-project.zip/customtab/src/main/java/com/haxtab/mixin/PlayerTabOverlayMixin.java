package com.haxtab.mixin;

import com.haxtab.client.ClientOpState;
import com.haxtab.client.TabLogic;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = PlayerTabOverlay.class, priority = 2000)
public abstract class PlayerTabOverlayMixin {

    private static boolean haxtab$logged = false;

    @Inject(method = "getPlayerInfos", at = @At("HEAD"), require = 0)
    private void haxtab$begin(CallbackInfoReturnable<List<PlayerInfo>> cir) {
        TabLogic.overlay = (PlayerTabOverlay) (Object) this;
        TabLogic.inTabQuery = true;
    }

    /** You first, then ranked players (OP/Admin/Owner text the server already shows), then everyone else. */
    @Inject(method = "getPlayerInfos", at = @At("RETURN"), cancellable = true)
    private void haxtab$order(CallbackInfoReturnable<List<PlayerInfo>> cir) {
        TabLogic.inTabQuery = false;
        List<PlayerInfo> original = cir.getReturnValue();
        if (original == null || original.isEmpty()) return;
        PlayerTabOverlay self = (PlayerTabOverlay) (Object) this;
        List<PlayerInfo> ordered = TabLogic.order(self, original);
        if (!haxtab$logged) {
            haxtab$logged = true;
            System.out.println("[HaxTab] Forced TAB ordering active. Entries: " + ordered.size());
        }
        cir.setReturnValue(ordered);
    }

    /** Real [OP] label, only for operators reported by the server-side companion. */
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void haxtab$opTag(PlayerInfo info, CallbackInfoReturnable<Component> cir) {
        if (ClientOpState.isOp(info.getProfile().id())) {
            cir.setReturnValue(Component.literal("[OP] ")
                    .withStyle(ChatFormatting.RED, ChatFormatting.BOLD)
                    .append(cir.getReturnValue()));
        }
    }
}
