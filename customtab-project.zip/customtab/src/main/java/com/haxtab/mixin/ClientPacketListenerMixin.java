package com.haxtab.mixin;

import com.haxtab.client.TabLogic;
import java.util.Collection;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** On big servers vanilla cuts the TAB list to 80 BEFORE we can reorder it, so you could be missing
 *  entirely. While the TAB list is being built, hand vanilla a list that already contains you and ranked players. */
@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {

    @Inject(method = "getListedOnlinePlayers", at = @At("RETURN"), cancellable = true, require = 0)
    private void haxtab$keepImportant(CallbackInfoReturnable<Collection<PlayerInfo>> cir) {
        if (!TabLogic.inTabQuery) return;
        TabLogic.inTabQuery = false;
        Collection<PlayerInfo> all = cir.getReturnValue();
        if (all == null || all.size() <= 80 || TabLogic.overlay == null) return;
        cir.setReturnValue(TabLogic.reduce(TabLogic.overlay, all, 80));
    }
}
