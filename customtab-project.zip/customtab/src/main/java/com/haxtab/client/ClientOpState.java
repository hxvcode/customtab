package com.haxtab.client;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class ClientOpState {
    private static volatile Set<UUID> ops = Collections.emptySet();

    public static void set(Collection<UUID> uuids) { ops = new HashSet<>(uuids); }
    public static void clear() { ops = Collections.emptySet(); }
    public static boolean isOp(UUID id) { return ops.contains(id); }

    private ClientOpState() {}
}
