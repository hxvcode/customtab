package com.haxtab.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;

/** Shared TAB ordering logic: [you] [ranked players: OP/Admin/Owner...] [everyone else]. */
public final class TabLogic {
    /** True only while PlayerTabOverlay is building its list (render thread). */
    public static boolean inTabQuery = false;
    /** The overlay currently asking for the list (set by the mixin). */
    public static PlayerTabOverlay overlay = null;

    private static final Map<PlayerInfo, Boolean> RANK_CACHE = new WeakHashMap<>();
    private static long lastClear = 0;

    public static int findSelf(PlayerTabOverlay o, List<PlayerInfo> list) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return -1;
        UUID self = mc.player.getUUID();
        String real = mc.getUser().getName();
        int byName = -1;
        for (int i = 0; i < list.size(); i++) {
            PlayerInfo pi = list.get(i);
            if (self.equals(pi.getProfile().id())) return i;
            if (byName < 0 && real != null && real.equalsIgnoreCase(pi.getProfile().name())) byName = i;
        }
        if (byName >= 0) return byName;
        if (!TabConfig.nicknames().isEmpty() && o != null) {
            for (int i = 0; i < list.size(); i++) {
                String shown = o.getNameForDisplay(list.get(i)).getString().toLowerCase(Locale.ROOT);
                for (String n : TabConfig.nicknames()) {
                    if (shown.contains(n)) return i;
                }
            }
        }
        return -1;
    }

    public static boolean isRanked(PlayerTabOverlay o, PlayerInfo info) {
        if (!TabConfig.rankFirst()) return false;
        if (ClientOpState.isOp(info.getProfile().id())) return true; // verified by server companion
        if (o == null) return false;
        long now = System.currentTimeMillis();
        if (now - lastClear > 1000) {
            RANK_CACHE.clear();
            lastClear = now;
        }
        Boolean c = RANK_CACHE.get(info);
        if (c != null) return c;
        boolean r = computeRanked(o, info);
        RANK_CACHE.put(info, r);
        return r;
    }

    /** Reads only text the server already shows: the words before the player's name. */
    private static boolean computeRanked(PlayerTabOverlay o, PlayerInfo info) {
        String shown = o.getNameForDisplay(info).getString();
        String name = info.getProfile().name();
        String prefix;
        int idx = (name == null || name.isEmpty()) ? -1 : shown.toLowerCase(Locale.ROOT).indexOf(name.toLowerCase(Locale.ROOT));
        if (idx >= 0) {
            prefix = shown.substring(0, idx);
        } else {
            int sp = shown.indexOf(' ');
            prefix = sp > 0 ? shown.substring(0, sp) : "";
        }
        for (String tok : prefix.split("[^A-Za-z0-9_]+")) {
            if (tok.isEmpty()) continue;
            if (TabConfig.rankKeywords().contains(tok.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    public static List<PlayerInfo> order(PlayerTabOverlay o, Collection<PlayerInfo> in) {
        List<PlayerInfo> all = new ArrayList<>(in);
        int s = findSelf(o, all);
        PlayerInfo me = s >= 0 ? all.remove(s) : null;
        List<PlayerInfo> ranked = new ArrayList<>();
        List<PlayerInfo> rest = new ArrayList<>();
        for (PlayerInfo p : all) {
            if (isRanked(o, p)) ranked.add(p); else rest.add(p);
        }
        List<PlayerInfo> out = new ArrayList<>(all.size() + 1);
        if (me != null) out.add(me);
        out.addAll(ranked);
        out.addAll(rest);
        return out;
    }

    /** Vanilla only keeps 80 entries; make sure you and ranked players are inside those 80. */
    public static List<PlayerInfo> reduce(PlayerTabOverlay o, Collection<PlayerInfo> in, int max) {
        List<PlayerInfo> ordered = order(o, in);
        return ordered.size() > max ? new ArrayList<>(ordered.subList(0, max)) : ordered;
    }

    private TabLogic() {}
}
