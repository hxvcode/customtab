package com.haxtab.client;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;

/**
 * config/haxtab.txt
 *   plain line        = a name the server shows for YOU (matched case-insensitive, colors ignored)
 *   rank=word         = a rank word to move up (matched as a prefix word before the player name)
 *   rankfirst=off     = turn off rank sorting
 */
public final class TabConfig {
    private static volatile List<String> nicknames = new ArrayList<>();
    private static volatile Set<String> ranks = defaultRanks();
    private static volatile boolean rankFirst = true;

    private static Set<String> defaultRanks() {
        return new LinkedHashSet<>(Arrays.asList("op", "admin", "owner"));
    }

    public static List<String> nicknames() { return nicknames; }
    public static Set<String> rankKeywords() { return ranks; }
    public static boolean rankFirst() { return rankFirst; }

    public static void load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("haxtab.txt");
        try {
            if (!Files.exists(p)) {
                Files.writeString(p, "# Haxtab\n"
                        + "# A plain line = the name the server shows for YOU in TAB (one per line).\n"
                        + "# rank=word   = extra rank word to move to the top (default: op, admin, owner)\n"
                        + "# rankfirst=off  = turn off moving ranked players up\n"
                        + "haxvq\n");
            }
            List<String> nicks = new ArrayList<>();
            Set<String> r = defaultRanks();
            boolean rf = true;
            for (String line : Files.readAllLines(p)) {
                String t = line.trim();
                if (t.isEmpty() || t.startsWith("#")) continue;
                String low = t.toLowerCase(Locale.ROOT);
                if (low.startsWith("rank=")) {
                    String w = low.substring(5).trim();
                    if (!w.isEmpty()) r.add(w);
                } else if (low.equals("rankfirst=off")) {
                    rf = false;
                } else if (low.equals("rankfirst=on")) {
                    rf = true;
                } else {
                    nicks.add(low);
                }
            }
            nicknames = nicks;
            ranks = r;
            rankFirst = rf;
        } catch (Exception e) {
            System.err.println("[haxtab] could not read config: " + e);
        }
    }

    private TabConfig() {}
}
