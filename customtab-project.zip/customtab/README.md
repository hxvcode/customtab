# Custom Tab List (Fabric, Minecraft 26.3)
- Client: you are always first in TAB (matched by UUID, custom server names kept). Shows [OP] for ops.
- Server: put the SAME jar on a Fabric server so it can send the real op list. Without it no [OP] is shown.
Build: install JDK 25 + Gradle 9+, run `gradle build` (or build.bat). Jar: build/libs/customtab-1.0.0.jar
Install (Dawn Launcher): Fabric Loader 0.20.1+ profile for 26.3, put customtab-1.0.0.jar and Fabric API 0.165.0+26.3 in the mods folder.
