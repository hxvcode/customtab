@echo off
REM Requires JDK 25 and Gradle 9+ on PATH (winget install Gradle.Gradle)
gradle build
echo Jar: build\libs\customtab-1.0.0.jar
pause
