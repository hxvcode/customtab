@echo off
REM Requires JDK 25 and Gradle 9+ on PATH (winget install Gradle.Gradle)
gradle build
echo Jar: build\libs\haxtab-mc26.2-1.2.1.jar
pause
